#pragma once

void draw_screen();
void draw_border();
void draw_alco();
