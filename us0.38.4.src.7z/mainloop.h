#pragma once

void __declspec(noreturn) mainloop(const volatile bool &Exit);
