#pragma once

bool done_fdd(bool Cancelable);
