#pragma once
extern const unsigned char daatab[];
