#pragma once
extern STEPFUNC const ix_opcode[];
