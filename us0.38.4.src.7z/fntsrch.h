#pragma once
void font_setup(HWND dlg);

