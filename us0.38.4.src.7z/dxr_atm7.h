#pragma once
void rend_atm7(unsigned char *dst, unsigned pitch);
