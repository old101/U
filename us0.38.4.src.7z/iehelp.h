#pragma once

void init_ie_help();
void done_ie_help();
void showhelppp(const char *anchor = nullptr);
