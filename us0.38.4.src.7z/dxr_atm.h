#pragma once

// small
void rend_atm_1_small(unsigned char *dst, unsigned pitch);
void rend_atm_2_small(unsigned char *dst, unsigned pitch);

// double
void rend_atm_1(unsigned char *dst, unsigned pitch);
void rend_atm_2(unsigned char *dst, unsigned pitch);
