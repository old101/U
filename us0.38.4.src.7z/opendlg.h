#pragma once

int GetSnapshotFileName(OPENFILENAME *ofn, int save);

