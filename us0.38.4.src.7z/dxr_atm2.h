#pragma once
void rend_atm2(unsigned char *dst, unsigned pitch, unsigned y, int Offset);
