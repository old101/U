#pragma once

void profi_writepal(u8 val);
