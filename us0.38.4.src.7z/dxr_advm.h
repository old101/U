#pragma once
void __fastcall render_advmame(unsigned char *dst, unsigned pitch);
