#pragma once
void rend_atm0_small(unsigned char *dst, unsigned pitch, unsigned y, int Offset);
void rend_atm0(unsigned char *dst, unsigned pitch, unsigned y, int Offset);
