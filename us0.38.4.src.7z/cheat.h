#pragma once
void main_cheat();
