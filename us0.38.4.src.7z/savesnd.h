#pragma once

void savesnddialog();
INT_PTR CALLBACK pokedlg(HWND dlg, UINT msg, WPARAM wp, LPARAM lp);
