#pragma once

void rend_profi(unsigned char *dst, unsigned pitch);
