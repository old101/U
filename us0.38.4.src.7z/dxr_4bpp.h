#pragma once

void rend_p4bpp_small(unsigned char *dst, unsigned pitch);
void rend_p4bpp(unsigned char *dst, unsigned pitch);
